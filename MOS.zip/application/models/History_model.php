<?php
class History_model extends CI_model
{
    private $f = '';        // filter
    private $o = '';        // order
    private $q = Null;        // query
    private $rs = Null;        // record set
    private $r = Null;        // current record
    private $c = 0;            // record count
    public function __construct()
    {
        $this->load->database();
    }
    public function History_user()
    {
        $sql = "
        SELECT * FROM `history_exam_user`
        ";
        $this->q = $this->db->query($sql);
        $this->rs = $this->q->result();
        $this->c = count($this->rs);
        $this->r = $this->q->row();
        return $this->rs;
    }
    
}

<?php
defined('BASEPATH') or exit('No direct script access allowed');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');

class Program extends CI_Controller
{

    //Admin
    public function index()
    {
        $this->load->model('Program_model');
        $r['program'] = $this->Program_model->get_program();
        $r['program_id'] = $this->Program_model->program_id();
        $r['checktraining'] = $this->Program_model->program_check_training();
        $r['exam_approve'] = $this->Program_model->exam_approve();
        $r['exam_archive_score_null'] = $this->Program_model-> exam_archive_score_null();
        $this->load->view('core/header', $r);
        $this->load->view('core/nav_admin');
        $this->load->view('admin/o_program', $r);
        $this->load->view('core/footer');
    }
    public function manage_exam_room()
    {
        $this->load->model('Program_model');
        $r['exam_room'] = $this->Program_model->exam_room();
        $r['program_id'] = $this->Program_model->program_id();
        $r['checktraining'] = $this->Program_model->program_check_training();
        $r['exam_approve'] = $this->Program_model->exam_approve();
        $r['exam_archive_score_null'] = $this->Program_model-> exam_archive_score_null();
        $this->load->view('core/header', $r);
        $this->load->view('core/nav_admin', $r);
        $this->load->view('admin/exam_room', $r);
        $this->load->view('core/footer');
    }
    public function exam_room_edit($id = "")
    {
        if (isset($id)) {
            $this->load->model('Program_model');
            $result['program'] = $this->Program_model->get_exam_room($id);
            $result['program_type'] = $this->Program_model->program_id();
            $r['checktraining'] = $this->Program_model->program_check_training();
            $r['exam_approve'] = $this->Program_model->exam_approve();
            $r['exam_archive_score_null'] = $this->Program_model-> exam_archive_score_null();
            $this->load->view('core/header', $r);
            $this->load->view('core/nav_admin', $r);
            $this->load->view('admin/exam_room_edit', $result);
            $this->load->view('core/footer');
        }
    }
    public function manage_pogram()
    {
        $this->load->model('Program_model');
        $r['program_type'] = $this->Program_model->program_type();
        $r['checktraining'] = $this->Program_model->program_check_training();
        $r['exam_approve'] = $this->Program_model->exam_approve();
        $r['exam_archive_score_null'] = $this->Program_model-> exam_archive_score_null();
        $this->load->view('core/header', $r);
        $this->load->view('core/nav_admin', $r);
        $this->load->view('admin/m_program', $r);
        $this->load->view('core/footer');
    }

    public function edit_program($id = "")
    {
        if (isset($id)) {
            $this->load->model('Program_model');
            $result['program'] = $this->Program_model->program_type_id($id);
            $r['checktraining'] = $this->Program_model->program_check_training();
            $r['exam_approve'] = $this->Program_model->exam_approve();
            $r['exam_archive_score_null'] = $this->Program_model-> exam_archive_score_null();
            $this->load->view('core/header', $r);
            $this->load->view('core/nav_admin', $r);
            $this->load->view('admin/m_program_edit', $result);
            $this->load->view('core/footer');
        }
    }
    public function edit_program_open($id = "")
    {
        if (isset($id)) {
            $this->load->model('Program_model');
            $result['program'] = $this->Program_model->get_program_id($id);
            $result['program_type'] = $this->Program_model->program_id();
            $r['checktraining'] = $this->Program_model->program_check_training();
            $r['exam_approve'] = $this->Program_model->exam_approve();
            $r['exam_archive_score_null'] = $this->Program_model-> exam_archive_score_null();
            $this->load->view('core/header', $r);
            $this->load->view('core/nav_admin', $r);
            $this->load->view('admin/o_program_edit', $result);
            $this->load->view('core/footer');
        }
    }
    public function check_training()
    {
        $this->load->model('Program_model');
        $r['checktraining'] = $this->Program_model->program_check_training();
        $r['exam_approve'] = $this->Program_model->exam_approve();
        $r['exam_archive_score_null'] = $this->Program_model-> exam_archive_score_null();
        $this->load->view('core/header', $r);
        $this->load->view('core/nav_admin', $r);
        $this->load->view('admin/check_training', $r);
        $this->load->view('core/footer');
    }
    public function training_pass()
    {
        $this->load->model('Program_model');
        $r['training_pass'] = $this->Program_model->program_training_pass();
        $r['checktraining'] = $this->Program_model->program_check_training();
        $r['exam_approve'] = $this->Program_model->exam_approve();
        $r['exam_archive_score_null'] = $this->Program_model-> exam_archive_score_null();
        $this->load->view('core/header', $r);
        $this->load->view('core/nav_admin', $r);
        $this->load->view('admin/training_pass', $r);
        $this->load->view('core/footer');
    }

    //User
    public function program_regis($id = "")
    {
        if (isset($id)) {
            $this->load->model('Program_model');
            $result['program'] = $this->Program_model->get_program_id($id);
            $result['program_type'] = $this->Program_model->program_id();
            $this->load->view('core/header');
            $this->load->view('program/program_regis', $result);
            $this->load->view('core/footer');
        }
    }
    public function program_member_list()
    {
        $this->load->model('Program_model');
        $r['tw'] = $this->Program_model->program_train_wait();
        $r['train_member'] = $this->Program_model->train_member($_SESSION['user_info']->personal_id);
        $r['exam_member'] = $this->Program_model->exam_member($_SESSION['user_info']->personal_id);
        $this->load->view('core/header');
        $this->load->view('program/program_member_list', $r);
        $this->load->view('core/footer');
    }
    
    public function list_program()
    {
        $this->load->model('program_model');
        $r['program'] = $this->program_model->get_program();
        $this->load->view('core/header');
        // $this->load->view('core/nav_admin');
        $this->load->view('program', $r);
        $this->load->view('core/footer');
    }
    public function error404()
    {
        $this->load->view('core/header');
        $this->load->view('error404');
        $this->load->view('core/footer');
    }
    // var_dump($user_data);

    //image
    public function upload_image_program()
    {
        $this->load->model('Upload_model');
        $this->Upload_model->upload_program_image();
    }
}

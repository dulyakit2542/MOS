<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function index()
    {
        $this->load->view('core/admin/header_admin');
        $this->load->view('admin/dashboard');
        $this->load->view('core/admin/footer_admin');
    }

    //TRAIN
    public function manage_room_train()
    {
        $this->load->model('Program_model');
        $this->load->model('User_model');
        $r['program'] = $this->Program_model->get_program();
        $r['program_id'] = $this->Program_model->program_id();
        $this->load->view('core/admin/header_admin');
        $this->load->view('admin/train/train_room', $r);
        $this->load->view('core/admin/footer_admin');
    }
    public function check_training()
    {
        $this->load->model('Program_model');
        $r['checktraining'] = $this->Program_model->program_check_training();
        $this->load->view('core/admin/header_admin');
        $this->load->view('admin/train/train_check', $r);
        $this->load->view('core/admin/footer_admin');
    }

    public function training_pass()
    {
        $this->load->model('Program_model');
        $r['training_pass'] = $this->Program_model->program_training_pass();
        $r['checktraining'] = $this->Program_model->program_check_training();
        $this->load->view('core/admin/header_admin');
        $this->load->view('admin/train/train_pass', $r);
        $this->load->view('core/admin/footer_admin');
    }
    public function manage_room_train_edit($data = "")
    {
        if (isset($data)) {
            $this->load->model('Program_model');
            $result['program'] = $this->Program_model->get_program_id($data);
            $result['program_type'] = $this->Program_model->program_id();
            $this->load->view('core/admin/header_admin');
            $this->load->view('admin/train/train_room_edit', $result);
            $this->load->view('core/admin/footer_admin');
        }
    }

    //EXAM
    public function manage_exam_room()
    {
        $this->load->model('Program_model');
        $r['exam_room'] = $this->Program_model->exam_room();
        $r['program_id'] = $this->Program_model->program_id();
        $this->load->view('core/admin/header_admin');
        $this->load->view('admin/exam/exam_room', $r);
        $this->load->view('core/admin/footer_admin');
    }
    public function manage_exam_room_edit($id = "")
    {
        if (isset($id)) {
            $this->load->model('Program_model');
            $result['program'] = $this->Program_model->get_exam_room($id);
            $result['program_type'] = $this->Program_model->program_id();
            $this->load->view('core/admin/header_admin');
            $this->load->view('admin/exam/exam_room_edit', $result);
            $this->load->view('core/admin/footer_admin');
        }
    }
    public function exam_approve()
    {
        $this->load->model('Program_model');
        $r['checktraining'] = $this->Program_model->program_check_training();
        $r['exam_approve'] = $this->Program_model->exam_approve();
        $r['exam_archive'] = $this->Program_model->exam_archive();
        $this->load->view('core/admin/header_admin');
        $this->load->view('admin/exam/exam_approve', $r);
        $this->load->view('core/admin/footer_admin');
    }
    public function exam_approve_define()
    {
        $this->load->model('Program_model');
        $r['checktraining'] = $this->Program_model->program_check_training();
        $r['exam_approve'] = $this->Program_model->exam_approve();
        $r['exam_define'] = $this->Program_model->exam_define();
        $r['exam_archive'] = $this->Program_model->exam_archive();
        $this->load->view('core/admin/header_admin');
        $this->load->view('admin/exam/exam_approve_define', $r);
        $this->load->view('core/admin/footer_admin');
    }

    //Program   
    public function manage_program()
    {
        $this->load->model('Program_model');
        $r['program_type'] = $this->Program_model->program_type();
        $this->load->view('core/admin/header_admin');
        $this->load->view('admin/program/manage_program', $r);
        $this->load->view('core/admin/footer_admin');
    }


    //USER


}

function show_openprogram() {
    $('#addprogram').modal('show')
}
function manage_room_train_edit(data) {
    console.log(data);

    window.location.href = base_url+'admin/manage_room_train_edit/' + data;
}


async function get_program_home() {
    var url = base_url + 'api_program/home/get_program';
    await $.ajax({
        type: 'GET',
        url: url,
        contentType: "json",
        error: function () {
            {
                swal("ข้อมูลกลุ่มอบรมซ้ำ", {
                    icon: "warning",
                })
            }
        },
        success: function (res) {
            let result = JSON.parse(res);
            const get_program = document.getElementById('get_program');
            get_program.innerHTML = ""
            result.result.map((items, idx) => {
                console.log(items);
                
                let btn_html = "";
                if (new Date() == new Date(items.program_date).setHours(23, 00, 00)) {
                    btn_html = `<a href="#"  class="badge badge-pill badge-danger">วันนี้</a>
                    `
                } else if (new Date() < new Date(items.program_date).setHours(23, 00, 00)) {
                    btn_html = `<h7 >${dateThai2(items.program_date)} </h7>
                    `
                } else if (new Date() > new Date(items.program_date).setHours(23, 00, 00)) {
                    btn_html = `<a href="#" class="badge badge-pill badge-danger">หมดเขต</a>
                    `
                }
                let badge_status = ""
                if (items.program_status == '5000') {
                    badge_status = `<a href="#" class="badge badge-pill badge-danger">ปิด</a>`
                } else {
                    badge_status = `<a href="#" class="badge badge-pill badge-success">เปิด</a>`
                }

                get_program.innerHTML += `<tr>
                        <td style="vertical-align: middle;">${items.program_open_id}</td>
                        <td style="vertical-align: middle;">${items.program_name}</td>
                        <td style="vertical-align: middle;" align="center">${badge_status}</td>
                        <td align="center" style="vertical-align: middle;">${btn_html}</td>
                        <td style="vertical-align: middle;">${items.program_room}</td>
                        <td style="vertical-align: middle;">${items.program_count < items.program_max ? `<h7  style="color: green;">${items.program_count}/${items.program_max}</h7>` : `<h7  style="color: red;">${items.program_count}/${items.program_max}</h7>`}</td>
                        <td style="vertical-align: middle;">${items.edit_program}, ${dateThaiJs(items.edit_program_date)}</td>
                        <td align="center" style="hight:1pt vertical-align: middle;" >
                                <a class="mb-1 btn btn-pill btn-success "  style="color: white;" onclick="manage_room_train_edit('${items.program_open_id}')">
                                    แก้ไข
                                </a>
                                <a class="mb-1 btn btn-pill btn-danger" style="color: white;" onclick="delete_program_open('${items.program_open_id}')">
                                    ลบ
                                </a>
                        </td>
                    </tr>`
                $(document).ready(function () {
                    $('#myTable').DataTable();
                });
            })
        }
    })
}
get_program_home()

function new_program() {
    var data = {
        program_open_id: $('#program_open_id').val(),
        program_name_id: $('#new_program_id').val(),
        program_room: $('#new_program_room').val(),
        program_date: $('#new_program_date').val(),
        program_status: $('#new_program_status').val(),
        program_max: $('#new_program_max').val(),
        edit_program: $('#edit_program').val(),
        edit_program_date: new Date,
    }
    console.log(data);
    Swal.fire({
        title: 'Are you sure?',
        text: "คุณต้องการเพิ่มห้องอบรมหรือไม่?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes'
    })
        .then((result) => {
            if (data['program_room'] == "" || data['program_date'] == "") {
                Swal.fire({
                    icon: 'info',
                    text: 'กรุณากรอกข้อมูลให้ครบ',
                })
            } else {
                if (result.isConfirmed) {

                    var url = base_url + 'api/program/insert_program/';
                    $.ajax({
                        type: 'POST',
                        url: url,
                        data: data,
                        contentType: "json",
                        error: function () {
                            Swal.fire({
                                icon: 'error',
                                title: 'ผิดพลาด',
                                text: 'มีรหัสหรือชื่อกลุ่มนี้อยู่แล้ว',
                            })
                        },
                        success: function () {
                            Swal.fire(
                                'สำเร็จ!',
                                'เพิ่มห้องอบรมเรียบร้อยแล้ว.',
                                'success'
                            )
                            setTimeout(function () {
                                location.reload();
                            }, 500);;
                        }
                    })
                } else {
                    swal("คุณไม่ได้บันทึกข้อมูล");
                }
            }
        });
}


function delete_program_open(id) {

    Swal.fire({
        title: 'Are you sure?',
        text: "คุณต้องการลบห้องอบรมหรือไม่?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes'
    })
        .then((result) => {
            if (result.isConfirmed) {
                var url = base_url+'api/program/delete_program_open/' + id;
                $.ajax({
                    type: 'DELETE',
                    url: url,
                    contentType: "json",
                    success: function () {
                        Swal.fire(
                            'สำเร็จ!',
                            'ลบห้องอบรมสำเร็จ.',
                            'success'
                        )
                        setTimeout(function () {
                            location.reload();
                        }, 1000);;
                    }
                })
            } else {
                swal("ยกเลิก");
            }
        });
}
function save_edit_program(id) {

    var data = {
        program_open_id: $('#program_open_id').val(),
        program_name_id: $('#edit_program_id').val(),
        program_date: $('#program_date').val(),
        program_status: $('#edit_program_status').val(),
        program_room: $('#edit_program_room').val(),
        program_max: $('#edit_program_max').val(),
        edit_program: $('#edit_program').val(),
        edit_program_date: new Date,
    }
    console.log(data);
    Swal.fire({
        title: 'Are you sure?',
        text: "คุณต้องการบันทึกข้อมูลหรือไม่?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes'
    })
        .then((result) => {
            if (data['program_open_id'] == "" || data['program_room'] == "" || data['program_name_id'] == "") {
                Swal.fire({
                    icon: 'info',
                    text: 'กรุณากรอกข้อมูลให้ครบ',
                })
            } else {
            if (result.isConfirmed) {
                var url = base_url+'api/program/edit_program/' + id;
                $.ajax({
                    type: 'POST',
                    url: url,
                    data: data,
                    contentType: "json",
                    error: function () {
                        {
                            Swal.fire({
                                icon: 'error',
                                title: 'ผิดพลาด',
                                text: 'มีรหัสหรือชื่อกลุ่มนี้อยู่แล้ว',
                            })
                        }
                    },
                    success: function () {
                        Swal.fire(
                            'สำเร็จ!',
                            'บันทึกข้อมูลสำเร็จ',
                            'success'
                        )
                        setTimeout(function () {
                            window.location = base_url+'admin/manage_room_train';
                        }, 500);;
                    }
                })
            } else {
                swal("คุณไม่ได้บันทึกข้อมูล");
            }
        }});
}



//USER

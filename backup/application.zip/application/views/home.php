<head>
  <title>หน้าหลัก : Testcenter</title>
  <?php 

// setHeight('home');
 
  ?> 
</head>
<style>
  .card1 {
    background-color: white;
    width: 100%;
    border-radius: 5px;
    box-shadow: 0 6px 10px rgba(0, 0, 0, .08), 0 0 6px rgba(0, 0, 0, .05);
    transition: .3s transform cubic-bezier(.155, 1.105, .295, 1.12), .3s box-shadow, .3s -webkit-transform cubic-bezier(.155, 1.105, .295, 1.12);

    /* padding: 14px 80px 18px 36px; */
    cursor: pointer;
  }

  .card1:hover {
    transform: scale(1.01);
    box-shadow: 0 10px 20px rgba(0, 0, 0, .12), 0 4px 8px rgba(0, 0, 0, .06);
  }

  @media(max-width: 990px) {
    .card {
      margin: 20px;
    }
  }
</style>

<body>

  <div class="container  wow fadeIn">
    <br>
    <section>
      <div class="">
        <?php
        // echo'<pre>';
        //     var_dump($_SESSION);
        ?>
        <table>
          <tr>
            <th colspan="3" style="width:60%;">
              <div id="carousel-example-1z" class="carousel slide  " data-ride="carousel" style="  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0px 0px 10px 0 rgba(0, 0, 0, 0.19); border-radius: 5px;">
                <!--Indicators-->
                <ol class="carousel-indicators">
                  <li data-target="#carousel-example-1z" data-slide-to="0" class="active"></li>
                  <li data-target="#carousel-example-1z" data-slide-to="1"></li>
                  <li data-target="#carousel-example-1z" data-slide-to="2"></li>
                </ol>
                <div class="carousel-inner" role="listbox">
                  <div class="carousel-item active">
                    <img style=" border-radius: 5px; background-size:cover;width:50%;" src="files/microsoft/mini/word.png" class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item">
                    <img style="border-radius: 5px; background-size:cover;width:50%;" src="files/microsoft/mini/excel.jpg" class="d-block w-100" alt="...">
                  </div>
                  <div class="carousel-item">
                    <img style="border-radius: 5px; background-size:cover;width:50%;" src="files/microsoft/mini/powerpoint.jpg" class="d-block w-100" alt="...">
                  </div>
                </div>
                <a class="carousel-control-prev" href="#carousel-example-1z" role="button" data-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carousel-example-1z" role="button" data-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
              </div>
            </td> 

            <th colspan="1" style="width:30%">
              <div class="">
                <section>
                  <div class="card1">
                    <div class="view view-cascade overlay">
                      <!-- <br><br> -->
                      <img style="border-top-left-radius: 5px; border-top-right-radius: 5px;" src="<?php echo base_url() . 'files/microsoft/co1.jpg' ?>" class="card-img-top" alt="">
                      <a>
                        <div class="mask rgba-white-slight"></div>
                      </a>
                    </div>
                  </div>
                </section>
              </div>
            </th> 
          </tr>

        </table>
      </div>
      <br>
      <hr>
      <br>
      <h2 style="text-align: center; font-size:25px; text-shadow: 0px 0px 2px #979797; color: #424242;" class="h2"><strong>โปรแกรมที่เปิดอบรม</strong> </h2>
      <br>
      <div class="row pb-4">
        <div class="col-md-4 mb-4">
          <section>
            <div class="card1">
              <div class="view view-cascade overlay">
                <!-- <br><br> -->
                <img style="border-top-left-radius: 5px; border-top-right-radius: 5px;" src="<?php echo base_url() . 'files/microsoft/word.png' ?>" class="card-img-top" alt="">
                <a>
                  <div class="mask rgba-white-slight"></div>
                </a>
              </div>
              <div class="card-body card-body-cascade text-center">
                <!-- Title -->
                <h4 class="h6"><strong>Microsoft Office Word 2016</strong></h4>
                <h5 class="h6">จำนวนที่นั่งคงเหลือ <h6 style="color: red;"><strong> 25/30 </strong></h6>
                </h5>
                <a target="" href="" class="btn btn-orange btn-rounded waves-effect waves-light"><strong class="h2" style="font-size:120%"> ลงทะเบียนอบรม</strong>
                </a>
              </div>
            </div>
          </section>
        </div>
        <div class="col-md-4 mb-4">
          <section>
            <div class="card1">
              <div class="view view-cascade overlay">
                <!-- <br><br> -->
                <img style="border-top-left-radius: 5px; border-top-right-radius: 5px;" src="<?php echo base_url() . 'files/microsoft/excel.jpg' ?>" class="card-img-top" alt="">
                <a>
                  <div class="mask rgba-white-slight"></div>
                </a>
              </div>
              <div class="card-body card-body-cascade text-center">
                <!-- Title -->
                <h4 class="h6"><strong>Microsoft Office Excel 2016</strong></h4>
                <h5 class="h6">จำนวนที่นั่งคงเหลือ <h6 style="color: red;"><strong> 30/30 </strong></h6>
                </h5>
                <a target="" href="" class="btn btn-orange btn-rounded waves-effect waves-light"><strong class="h2" style="font-size:120%"> ที่นั่งเต็ม</strong>
                </a>
              </div>
            </div>
          </section>
        </div>
        <div class="col-md-4 mb-4">
          <section>
            <div class="card1 ">
              <div class="view view-cascade overlay">
                <!-- <br><br> -->
                <img style="border-top-left-radius: 5px; border-top-right-radius: 5px;" src="<?php echo base_url() . 'files/microsoft/powerpoint.jpg' ?>" class="card-img-top" alt="">
                <a>
                  <div class="mask rgba-white-slight"></div>
                </a>
              </div>
              <div class="card-body card-body-cascade text-center">
                <!-- Title -->
                <h4 class="h6"><strong>Microsoft Office Powerpoint 2016</strong></h4>
                <h5 class="h6">จำนวนที่นั่งคงเหลือ <h6 style="color: red;"><strong> - </strong></h6>
                </h5>
                <a target="" href="" class="btn btn-orange btn-rounded waves-effect waves-light"><strong class="h2" style="font-size:120%"> ยังไม่เปิดให้บริการ</strong>
                </a>
              </div>
            </div>
          </section>
        </div>
      </div>
    </section>
  </div>

</body>

<script>

</script>
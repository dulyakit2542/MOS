<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>TESTCENTER RMUTI</title>

  <link href="<?php echo base_url() . 'theme/Bootstrap-4-templates-master/full-page-image-carousel/' ?>css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url() . 'theme/Bootstrap-4-templates-master/full-page-image-carousel/' ?>css/mdb.min.css" rel="stylesheet">
  <link href="<?php echo base_url() . 'theme/Bootstrap-4-templates-master/full-page-image-carousel/' ?>css/style.min.css" rel="stylesheet">
  <link href="<?php echo base_url() . 'theme/MDB' ?>/css/mdb.min.css" rel="stylesheet" />
  <link href="<?php echo base_url() . 'theme/MDB' ?>/css/bootstrap.min.css" rel="stylesheet" />
  <link href="<?php echo base_url() . 'theme/MDB' ?>/css/mdb.min.css" rel="stylesheet" />
  <link href="<?php echo base_url() . 'theme/Fonts' ?>/promt/stylesheet.css" rel="stylesheet" />

</head>
<style>
  .text_head {
    font-family: 'promptmedium';
    font-size: 100%;
  }

  .h2 {
    font-family: 'promptlight';
  }

  .h6 {
    font-family: 'promptlight';
  }
</style>
<body>

  <div class="view">
    <video class="video-intro" autoplay loop muted>
      <source class="view jarallax" src="https://mdbootstrap.com/img/video/animation-intro.mp4" type="video/mp4" data-jarallax='{"speed": 0.2}'>
    </video>

    <!-- Mask & flexbox options-->
    <div class="mask rgba-black-light d-flex justify-content-center align-items-center">

      <!-- Content -->
      <div class="text-center white-text mx-5 wow fadeIn">
        <img src="files/design/RMUTI_KORAT.png" style="margin:auto; width: 15%;  filter: drop-shadow(0px 2px 2px #222); " alt="RMUTI">
        <br>
        <p style="font-family: promptlight; font-size: 140%;">Program Support Information Technology Testing Centers
          RMUTI.
        </p>
        <p class="h2" style="font-size: 140%;">
          <strong>ยินดีต้อนรับสู่โปรแกรมสนับสนุนศูนย์สอบวัดความรู้ด้านเทคโนโลยีสารสนเทศ มทร.อีสาน</strong>
        </p>
        <br>
        <p class="h2" style="font-size: 140%; color:red">
          <strong>(ยังไม่เปิดให้บริการ)</strong>
        </p>
        <br>
        <a target="" href="<?php echo base_url('home') ?>" class="btn btn-deep-orange waves-effect waves-light"><strong class="h2" style="font-size: 120%;"> เข้าสู่เว็บไซต์</strong>
          <i class="fas fa-graduation-cap ml-2"></i>
          <!-- btn btn-deep-orange waves-effect waves-light -->
        </a>
      </div>
    </div>
  </div>

</body>

</html>
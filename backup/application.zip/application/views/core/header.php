<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<meta http-equiv="x-ua-compatible" content="ie=edge">

<!-- style -->
<link href="<?php echo base_url() . 'theme/Bootstrap-4-templates-master/full-page-image-carousel/' ?>css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url() . 'theme/Bootstrap-4-templates-master/full-page-image-carousel/' ?>css/mdb.min.css" rel="stylesheet">
<link href="<?php echo base_url() . 'theme/Bootstrap-4-templates-master/full-page-image-carousel/' ?>css/style.min.css" rel="stylesheet">
<link href="<?php echo base_url() . 'theme/MDB' ?>/css/mdb.min.css" rel="stylesheet" />
<link href="<?php echo base_url() . 'theme/MDB' ?>/css/bootstrap.min.css" rel="stylesheet" />
<link href="<?php echo base_url() . 'theme/MDB' ?>/css/mdb.min.css" rel="stylesheet" />
<link href="<?php echo base_url() . 'theme/MDB' ?>/js/vendor/fullcalendar-3.10.0/fullcalendar.min.css" rel="stylesheet" />
<link href="<?php echo base_url() . 'theme/Fonts' ?>/promt/stylesheet.css" rel="stylesheet" />
<!-- style -->
<style>
  .text_head {
    font-family: 'promptlight';
    font-weight: bold;
    color: #707070;
    opacity: 1.0;
    filter: alpha(opacity=100);
  }

  .text_head:hover {
    font-family: 'promptlight';
    font-weight: bold;
    color: #FF6100;
    opacity: 1.0;
    filter: alpha(opacity=100);
  }

  .text_drop {
    font-family: 'promptlight';
    color: #707070;
    opacity: 1.0;
    filter: alpha(opacity=100);
  }

  .text_drop:hover {
    font-family: 'promptlight';
    color: #FF6100;
    color: #FF6100;
    opacity: 1.0;
    filter: alpha(opacity=100);
  }

  .h2 {
    font-family: 'promptlight';
  }

  .h6 {
    font-family: 'promptlight';
  }
</style>
<nav>
  <nav class="navbar navbar-light  navbar-expand-lg  bg-white  scrolling-navbar">
    <!-- container -->
    <div class="container">
      <img src="files/logo3.png" style="margin:left; width:40%;">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto" style="margin: auto; ">
          <li class="text_head ">
            <!-- <?php
           function setHeight(String $minheight)
             {
             if ($minheight == 'home') {
           ?>
           <a style="color: #FF6100;" class="text_head" href="<?php echo base_url() . 'Home' ?>">หน้าหลัก <span class="sr-only"></span></a> &nbsp;
             <?php } else {
             ?>
           <a class="text_head" href="<?php echo base_url() . 'Home' ?>">หน้าหลัก <span class="sr-only"></span></a> &nbsp;
            <?php  }
            }
            ?> -->
           <a class="text_head" href="<?php echo base_url() . 'Home' ?>">หน้าหลัก <span class="sr-only"></span></a> &nbsp;


          </li>

          <li class="text_head">
            <a class="text_head" href="<?php echo base_url() . 'program' ?>">โปรแกรมที่เปิดสอบ</a> &nbsp;
          </li>
          <li class="text_head">
            <a class="text_head" href="#">คู่มือการใช้งาน</a> &nbsp;
          </li>
          <?php
          $permission_admin = false;
          if (count($_SESSION) > 1) {
            foreach ($_SESSION['permission'] as $row) {
              if ($row->text_type == 'admin') {
                $permission_admin = true;
              }
            }
          }
          // var_dump($_SESSION);
          if ($permission_admin) {
          ?>
            <li class="text_head">
              <a class="text_head" href="#">Admin</a> &nbsp;
            </li>
          <?php
          }
          $permission_user = false;
          if (count($_SESSION) > 1) {
            foreach ($_SESSION['permission'] as $row) {
              if ($row->text_type == 'user') {
                $permission_user = true;
              }
            }
          }
          // echo'<pre>';
          // var_dump($_SESSION);
          if ($permission_user || $permission_admin) {
          ?>
            <li class="text_head btn-group">
              <a class="text_head dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <!-- <a class="nav-link dropdown-toggle waves-effect" href="#" id="userDropdown" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false"> -->
                <i class="fas fa-user"></i> <span class="clearfix d-none d-sm-inline-block">Profile</span>
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#">โปรแกรมที่ลงทะเบียน</a>
                <a class="dropdown-item" href="#">จองที่นั่งสอบ</a>
                <a class="dropdown-item" href="#">ผลการสอบ</a>
                <a class="dropdown-item" href="#">ข้อมูลส่วนตัว</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item waves-effect" href="<?php echo base_url() . 'login/logout' ?>">ออกจากระบบ</a>
              </div>
            </li>
          <?php
          } else {
          ?>
            <li class="text_head">
              <a class="text_head" href="<?php echo base_url() . 'login' ?>">Login</a> &nbsp;
            </li>
          <?php
          }
          ?>


        </ul>
      </div>
    </div>
  </nav>
</nav>

<!-- MDB core JavaScript -->
<script type="text/javascript" src="<?php echo base_url() . 'theme/MDB' ?>/js/jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'theme/MDB' ?>/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'theme/MDB' ?>/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'theme/MDB' ?>/js/vendor/fullcalendar-3.10.0/lib/moment.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'theme/MDB' ?>/js/vendor/fullcalendar-3.10.0/fullcalendar.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'theme/MDB' ?>/js/mdb.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'theme/Bootstrap-4-templates-master/full-page-image-carousel/' ?>js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'theme/Bootstrap-4-templates-master/full-page-image-carousel/' ?>js/bootstrap.min.js"></script>

<script src="<?php echo base_url() . 'theme/js' ?>/java.js"></script>
<!-- MDB core JavaScript -->

<script type="text/javascript">
  new WOW().init();
</script>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class login extends CI_Controller {

	public function index()
	{
        // $this->load->view('core/header');
        // $this->load->view('core/header');
        $this->load->view('login');
        // $this->load->view('core/footer');

    }
    public function check_login(){
        $user_data = $this->input->post();
        // var_dump($data);
        $this->load->model('user');
        $r = $this->user->check_login($user_data);
        if($r){
            $this->session->set_userdata($r);
            // echo'<pre>';
            // var_dump($_SESSION);
            
            redirect('/home', 'refresh');
        }else{
            redirect('/login', 'refresh');
        }
        
        
        
        
    }
    public function logout(){
        session_destroy();
        redirect('/login', 'refresh');
    }
}
     
?>

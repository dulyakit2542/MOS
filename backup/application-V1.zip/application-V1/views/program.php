<title>RMUTI : Program</title>
<style>
  .card1 {
    background-color: white;
    width: 100%;
    border-radius: 10px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 0px 20px 0 rgba(0, 0, 0, 0.19);
  }
</style>
<div class="container  wow fadeIn">
  <br>
  <table>
    <tr>
      <td>
        <div class="row pb-4">
          <div class="col-md-4 mb-4">
            <section>
              <div class="card1">
                <div class="view view-cascade overlay">
                  <!-- <br><br> -->
                  <img style="border-top-left-radius: 10px; border-top-right-radius: 10px;" src="<?php echo base_url() . 'files/microsoft/word.png' ?>" class="card-img-top" alt="">
                  <a>
                    <div class="mask rgba-white-slight"></div>
                  </a>
                </div>
                <div class="card-body card-body-cascade text-center">
                  <!-- Title -->
                  <h4 class="h6"><strong>Microsoft Office Word 2016</strong></h4>
                  <h5 class="h6">จำนวนที่นั่งคงเหลือ <h6 style="color: red;"><strong> 25/30 </strong></h6></h5>
                  <a target="" href="" class="btn btn-orange btn-rounded waves-effect waves-light"><strong class="h2" style="font-size:120%"> ลงทะเบียนอบรม</strong>
                  </a>
                </div>
              </div>
            </section>
          </div>
          <div class="col-md-4 mb-4">
            <section>
              <div class="card1">
                <div class="view view-cascade overlay">
                  <!-- <br><br> -->
                  <img style="border-top-left-radius: 10px; border-top-right-radius: 10px;" src="<?php echo base_url() . 'files/microsoft/excel.jpg' ?>" class="card-img-top" alt="">
                  <a>
                    <div class="mask rgba-white-slight"></div>
                  </a>
                </div>
                <div class="card-body card-body-cascade text-center">
                  <!-- Title -->
                  <h4 class="h6"><strong>Microsoft Office Excel 2016</strong></h4>
                  <h5 class="h6">จำนวนที่นั่งคงเหลือ <h6 style="color: red;"><strong> 30/30 </strong></h6></h5>
                  <a target="" href="" class="btn btn-orange btn-rounded waves-effect waves-light"><strong class="h2" style="font-size:120%"> ที่นั่งเต็ม</strong>
                  </a>
                </div>
              </div>
            </section>
          </div>
          <div class="col-md-4 mb-4">
            <section>
              <div class="card1 ">
                <div class="view view-cascade overlay">
                  <!-- <br><br> -->
                  <img style="border-top-left-radius: 10px; border-top-right-radius: 10px;" src="<?php echo base_url() . 'files/microsoft/powerpoint.jpg' ?>" class="card-img-top" alt="">
                  <a>
                    <div class="mask rgba-white-slight"></div>
                  </a>
                </div>
                <div class="card-body card-body-cascade text-center">
                  <!-- Title -->
                  <h4 class="h6"><strong>Microsoft Office Powerpoint 2016</strong></h4>
                  <h5 class="h6">จำนวนที่นั่งคงเหลือ <h6 style="color: red;"><strong> - </strong></h6></h5>
                  <a target="" href="" class="btn btn-orange btn-rounded waves-effect waves-light"><strong class="h2" style="font-size:120%"> ยังไม่เปิดให้บริการ</strong>
                  </a>
                </div>
              </div>
            </section>
          </div>
        </div>
      </td>
    </tr>
  </table>
</div>
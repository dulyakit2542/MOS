<style>
  .h7 {
    font-family: 'promptmedium';
    font-size: 10pt;
    color: #3d4345;
    text-align: left;
  }

  .p1 {
    font-family: 'promptmedium';
    font-weight:bold;
    font-size: 12pt;
    color: #3d4345;
    text-align: left;
    margin: 30px 100px 0px 12px;
  }

  .p2 {
    font-family: 'promptmedium';
    font-weight: normal;
    font-size: 10pt;
    color: #3d4345;
    text-align: left;
    margin: auto ;
    opacity: 1.0;
    filter: alpha(opacity=100);
  }

  .p2:hover {
    font-family: 'promptmedium';
    font-size: 10pt;
    color: #FF6100;
    text-align: left;
    margin: auto ;
    opacity: 1.0;
    filter: alpha(opacity=100);
  }
  .p3 {
    font-family: 'promptmedium';
    font-weight: normal;
    font-size: 10pt;
    color: #3d4345;
    text-align: left;
    margin: auto ;
    opacity: 1.0;
    filter: alpha(opacity=100);
  }
</style>
<section style="background-color: #DDDDDD;">
  <!--First row-->
  <div class="container row features-small  wow fadeIn" style="margin: auto;">
    <!--Grid column-->
    <div class="col-xl-4 ">
      <!--Grid row-->
      <div class="row">
        <p class="p1 " > หน่วยงานภายใน</p>
        <div class="col-10">
          <br>
          <a target="_blank" href="https://www.rmuti.ac.th/2019/">
            <p class="p2"> มทร.อีสาน</p>
          </a>
         <br>
          <a target="_blank" href="http://oop.rmuti.ac.th/web/">
            <p class="p2"> สำนักงานอธิการบดี</p>
          </a>
         <br>
          <a target="_blank" href="http://www.oarit.rmuti.ac.th/">
            <p class="p2"> สำนักวิทยบริการและเทคโนโลยีสารสนเทศ</p>
          </a>
         <br>
          <a target="_blank" href="http://www.oapr.rmuti.ac.th/">
            <p class="p2"> สำนักส่งเสริมวิชาการและงานทะเบียน</p>
          </a>
         <br>
        </div>
      </div>

      <!--/Grid row-->
    </div>
    <!--/Grid column-->
    <div class="col-xl-4">
      <!--Grid row-->
      <div class="row">
        <div class="col-10 ">
          <br>
          
          <a target="_blank" href="http://www.ba.rmuti.ac.th/">
            <p class="p2"> คณะบริหารธุรกิจ</p>
          </a>
         <br>
          <a target="_blank" href="http://www.sci.rmuti.ac.th/">
            <p class="p2"> คณะวิทยาศาสตร์และศิลปศาสตร์</p>
          </a>
         <br>
          <a target="_blank" href="http://www.ea.rmuti.ac.th/">
            <p class="p2">  คณะวิศวกรรมศาสตร์และสถาปัตยกรรมศาสตร์</p>
          </a>
         <br>
          <a target="_blank" href="http://www.aid.rmuti.ac.th/">
            <p class="p2"> คณะศิลปกรรมและออกแบบอุตสาหกรรม</p>
          </a>
         <br>
         <a target="_blank" href="http://cis.rmuti.ac.th/2020/">
            <p class="p2"> วิทยาลัยนวัตกรรมวิชาชีพ</p>
          </a>
         <br>

        </div>
      </div>
 
    </div>

    <!--Grid column-->
    <!-- <div class="col-2">
      <div class="row">
        <p class="p1">หน่วยงานที่เกี่ยวข้อง</p> <br>
        <div class="col-10 ">
          <br>
          <a target="_blank" href="http://lms.rmuti.ac.th/">
            <p class="p2"> RMUTI LMS</p>
          </a>
         <br>
          <a target="_blank" href="https://www.microsoft.com/th-th/microsoft-365">
            <p class="p2"> Microsoft 365</p>
          </a>
         <br>
          <a target="_blank" href="https://www.office.com/">
            <p class="p2"> Office 365</p>
          </a>
         <br>

        </div>
      </div>
 
    </div> -->

    <!--/Grid row-->
    <div class="col-xl-4">
      <!--Grid row-->
      <div class="row">
        <p class="p1">ติดต่อเรา</p> <br>
        <div class="col-10 ">
          <br>
            <p class="p3"> <i class="fas fa-map-marker-alt"></i> <strong>ที่อยู่: </strong>ศูนย์สอบวัดความรู้ด้านเทคโนโลยีสารสนเทศ ชั้น4 สำนักวิทยบริการและเทคโนโลยีสารสนเทศ </p>
            <p class="p3"> <strong>โทรศัพท์: </strong>0123456</p>
            
<br>

        </div>
      </div>
 
    </div>
  </div>
  </div>
  <!--/Second row-->

</section>
<footer style="background-color: #CFCFCF;">

  </div>
  <div class="footer-copyright py-3 text-center">
    <h7 class="h7">
      ©2021 Copyright 2021 : CPE-RMUTI. All Rights Reserved.
    </h7>
  </div>

</footer>
<script type="text/javascript" src="<?php echo base_url() . 'theme/fontawesome-free-5.14.0-web/' ?>js/all.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'theme/Bootstrap-4-templates-master/full-page-image-carousel/' ?>js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'theme/Bootstrap-4-templates-master/full-page-image-carousel/' ?>js/bootstrap.min.js"></script>
<script type="text/javascript">
  new WOW().init();
</script>
</body>

</html>
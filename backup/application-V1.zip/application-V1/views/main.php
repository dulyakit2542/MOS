<!--Main layout-->

<main>


  <div class="container">
    <section class="view intro-2">
      <!--Section: Main info-->
      <section class="mt-5 wow fadeIn">
        <!--Grid row-->
        <div class="row">
          <!--Grid column-->
          <div class="col-md-12">
            <div class="row">
              <div class="col-md-12">
                <br>
                <br>
                <br>
                <br>

                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <?php
                // var_dump($game);
                ?>
                <!-- แถว -->
                <div class="row">

               
                    <div class="col-md-4">
                      <!-- Card -->
                      <div class="card">
                        <!-- Card image -->
                        <img class="card-img-top"  alt="Card image cap">
                        <!-- Card content -->
                        <div class="card-body">
                          <!-- Title -->
                         
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-12">
                          <br>
                          <br>
                        </div>
                      </div>
                      <!-- Card -->
                    </div>
                

                </div>

                <!-- Pagination -->
                <nav class="my-4">
                  <ul class="pagination pg-blue">
       
                  

                    <!-- Last -->
                    <li class="page-link waves-effect waves-effect"></a></li>

                </nav>


                </ul>
                </nav>

                <!-- สุดแถว -->
              </div>


          

            </div>

          </div>
          <!--/Grid column-->

        </div>
        <!--/Second row-->
<!-- Large modal -->


</div>
</div>
</div>
</body>
<!-- jQuery and JS bundle w/ Popper.js -->
  </div>
  <!-- </div> -->
  <!-- JQuery -->




</main>
<!--Main layout-->
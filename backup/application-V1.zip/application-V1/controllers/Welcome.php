<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
        // $this->load->view('core/header');
        // $this->load->view('core/header');
        $this->load->view('welcome');
        // $this->load->view('core/footer');

    }
}
     
?>

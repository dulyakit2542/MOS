<?php
class Room extends CI_model
{
    private $f = '';        // filter
    private $o = '';        // order

    private $q = Null;        // query
    private $rs = Null;        // record set
    private $r = Null;        // current record
    private $c = 0;            // record count
    public function __construct()
    {
        $this->load->database();
    }

    // public function user_login($user_data){

    //     $this->db->where('email', $user_data['email']);
    //     $this->db->where('password', $user_data['password']);
    //     $query = $this->db->get('user');
    //     if($query->row() > 0){
    //         return true;
    //     }else{
    //         return false;
    //     }


    // }

    // public function create_user($user_data){
    //     $this->db->insert('user',$user_data);
    // }

    public function get_room()
    {
        $sql = "
		SELECT
	    *
        FROM
        room_central,
        room_number
        INNER JOIN
        room_report
        ON 
            room_number.room_number_no = room_report.room_report_number
        INNER JOIN
        room_report_type
        ON 
            room_report.room_report_type = room_report_type.room_report_type_num
        INNER JOIN
        room
        ON 
            room_number.room_type = room.room_number
            "
            ;
        $this->q = $this->db->query($sql);
        $this->rs = $this->q->result();
        $this->c = count($this->rs);
        $this->r = $this->q->row();
        //array_push($this->rs, array('sql'=>$sql));
        return $this->rs;
    }
   
    public function get_by_id($id)
    {
        $sql = "
		SELECT
        *
        FROM
        room_central,
        room_number
        INNER JOIN
        room_report
        ON 
            room_number.room_number_no = room_report.room_report_number
        INNER JOIN
        room_report_type
        ON 
            room_report.room_report_type = room_report_type.room_report_type_num
        INNER JOIN
        room
        ON 
            room_number.room_type = room.room_number
            WHERE
            room_number.room_number_no = $id
            ";
        $this->q = $this->db->query($sql);
        $this->rs = $this->q->result();
        $this->c = count($this->rs);
        $this->r = $this->q->row();
        //array_push($this->rs, array('sql'=>$sql));
        return $this->rs;
    }

    public function get_group()
    {
        $sql = "
		SELECT * FROM `group_game`
		";
        $this->q = $this->db->query($sql);
        $this->rs = $this->q->result();
        $this->c = count($this->rs);
        $this->r = $this->q->row();
        //array_push($this->rs, array('sql'=>$sql));
        return $this->rs;
    }
    public function get_company()
    {
        $sql = "
		SELECT * FROM `company`
		";
        $this->q = $this->db->query($sql);
        $this->rs = $this->q->result();
        $this->c = count($this->rs);
        $this->r = $this->q->row();
        //array_push($this->rs, array('sql'=>$sql));
        return $this->rs;
    }
    public function get_system()
    {
        $sql = "
		SELECT * FROM `system`
		";
        $this->q = $this->db->query($sql);
        $this->rs = $this->q->result();
        $this->c = count($this->rs);
        $this->r = $this->q->row();
        //array_push($this->rs, array('sql'=>$sql));
        return $this->rs;
    }
    public function update_game($id, $data)
    {
        // echo '<pre>';
        // var_dump($data);
        $this->db->where('id', $id);
        $this->db->update('game', $data);
    }
    public function del_game($id)
    {
        //  echo '<pre>';
        // var_dump($data);
        $this->db->where('id', $id);
        $this->db->delete('game');
    }
    public function insert_game($data)
    {
        // echo '<pre>';
        // var_dump($data);
        $this->db->insert('game', $data);
    }
    public function new_game($data)
    {
        return ($this->db->insert('game', $data)) ? true : false;
    }
}

<?php
class User extends CI_model{
    private $f = '';		// filter
	private $o = '';		// order

	private $q = Null;		// query
	private $rs = Null;		// record set
	private $r = Null;		// current record
	private $c = 0;			// record count
    public function __construct()
    {
        $this->load->database();
    }

    public function user_login($user_data){
        
        $this->db->where('email', $user_data['email']);
        $this->db->where('password', $user_data['password']);
        $query = $this->db->get('user');
        if($query->row() > 0){
            return true;
        }else{
            return false;
        }

        
    }
    public function user_admin($user_data){
        
        $this->db->where('email', $user_data['email']);
        $this->db->where('password', $user_data['password']);
        $query = $this->db->get('user_admin');
        if($query->row() > 0){
            return true;
        }else{
            return false;
        }

        
    }
    public function register2($user_data){
        
        $this->db->where('email', $user_data['email']);
        $this->db->where('password', $user_data['password']);
        $query = $this->db->get('user');
        if($query->row() > 0){
            return true;
        }else{
            return false;
        }

        
    }

    public function create_user($user_data){
        $this->db->insert('user',$user_data);
    }


    

    // public function daaas(){
    //     $sql = "
		
	// 	"
	// ;
	// 	$this->q = $this->db->query($sql);

	// 	$this->rs = $this->q->result();
	// 	$this->c = count($this->rs);
	// 	$this->r = $this->q->row();
	// 	//array_push($this->rs, array('sql'=>$sql));
	// 	return $this->rs;

        
    // }
    
}

